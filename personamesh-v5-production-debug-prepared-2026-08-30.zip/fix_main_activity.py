import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# I want to find the work manager enqueues inside onCreate
# They are generally inside `// Setup WorkManager for periodic tasks`
# Let's see how it looks.
