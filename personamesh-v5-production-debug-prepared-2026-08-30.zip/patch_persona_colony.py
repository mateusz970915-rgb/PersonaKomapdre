import re

with open('app/src/main/java/com/example/ui/PersonaColonyScreen.kt', 'r') as f:
    content = f.read()

target = """fun PersonaColonyScreen(
    viewModel: ColonyViewModel,
    onBack: () -> Unit
) {"""

replacement = """fun PersonaColonyScreen(
    viewModel: ColonyViewModel,
    onBack: () -> Unit,
    onNavigateToDashboard: () -> Unit = {}
) {"""

if target in content:
    content = content.replace(target, replacement)
    
    # Now find where to add the button
    target_btn = """                actions = {
                    IconButton(
                        onClick = { showAddAgentDialog = true },"""
    replacement_btn = """                actions = {
                    IconButton(
                        onClick = { onNavigateToDashboard() },
                        modifier = Modifier.testTag("colony_dashboard_btn")
                    ) {
                        Icon(
                            androidx.compose.material.icons.Icons.Default.Dashboard,
                            contentDescription = "Colony Dashboard",
                            tint = androidx.compose.material3.MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = { showAddAgentDialog = true },"""
    if target_btn in content:
        content = content.replace(target_btn, replacement_btn)
    
    with open('app/src/main/java/com/example/ui/PersonaColonyScreen.kt', 'w') as f:
        f.write(content)
    print("PersonaColonyScreen updated")
else:
    print("Target not found in PersonaColonyScreen")
