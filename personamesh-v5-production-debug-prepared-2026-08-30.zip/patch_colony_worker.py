import re

with open('app/src/main/java/com/example/worker/ColonyBackgroundProcessingWorker.kt', 'r') as f:
    content = f.read()

target = """                // Log result to memory
                dao.insertMemory(ColonyMemory(content = "Background Task [${task.id}] by ${agent.name}: ${result.logMessage}"))
            }"""

replacement = """                // Log result to memory
                dao.insertMemory(ColonyMemory(content = "Background Task [${task.id}] by ${agent.name}: ${result.logMessage}"))
                
                if (isTerminal && result.status != "FAILED") {
                    val inputData = androidx.work.Data.Builder()
                        .putInt("TASK_ID", task.id)
                        .build()
                    val notificationRequest = androidx.work.OneTimeWorkRequestBuilder<AgentTaskNotificationWorker>()
                        .setInputData(inputData)
                        .build()
                    androidx.work.WorkManager.getInstance(applicationContext).enqueue(notificationRequest)
                }
            }"""

if target in content:
    content = content.replace(target, replacement)
    with open('app/src/main/java/com/example/worker/ColonyBackgroundProcessingWorker.kt', 'w') as f:
        f.write(content)
    print("Patched successfully")
else:
    print("Target not found")
