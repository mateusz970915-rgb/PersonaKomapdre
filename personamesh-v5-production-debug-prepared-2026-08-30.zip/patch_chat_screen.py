import re

with open('app/src/main/java/com/example/ui/InterAgentChatScreen.kt', 'r') as f:
    content = f.read()

target = """val topics = listOf("All", "Task Synchronization", "Colony Health & Balance", "Governance & Privacy", "Task Assignment")"""
replacement = """val topics = listOf("All", "Collaboration", "Task Synchronization", "Colony Health & Balance", "Governance & Privacy", "Task Assignment")"""

if target in content:
    content = content.replace(target, replacement)
    with open('app/src/main/java/com/example/ui/InterAgentChatScreen.kt', 'w') as f:
        f.write(content)
    print("Added Collaboration topic")
else:
    print("Target not found")
