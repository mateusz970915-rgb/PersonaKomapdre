package com.example.edde

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.AppDatabase
import com.example.data.edde.EddeDao
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class EDDEPipelineIntegrationTest {

    private lateinit var db: AppDatabase
    private lateinit var dao: EddeDao
    private lateinit var runtime: EDDERuntime
    private lateinit var orchestrator: EDDEPipelineOrchestrator

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        db = AppDatabase.getDatabase(context)
        dao = db.eddeDao()
        runtime = EDDERuntime(dao)
        orchestrator = EDDEPipelineOrchestrator(runtime, dao)
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun testCreateCycleInitializes14Phases() = runBlocking {
        val run = runtime.createCycle(
            agentId = "test-agent",
            objective = "Test objective",
            authorizationBoundary = "test",
            successCriteria = listOf("criterion1")
        )

        assertNotNull(run)
        assertEquals("active", run.status)
        assertEquals(0, run.currentPhase)

        val phases = dao.getPhaseResultsForRun(run.runId)
        assertEquals(14, phases.size)
        assertTrue(phases.all { it.status == "pending" })
    }

    @Test
    fun testRunPipelineCompletesAll14Phases() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val result = orchestrator.runPipeline(
            context = context,
            agentId = "test-agent",
            objective = "Explain Kotlin coroutines",
            authorizationBoundary = "test"
        )

        assertTrue("Pipeline should complete successfully", result.isSuccess)

        // Find the run (most recent for this agent)
        val runs = dao.getPipelineRunsForAgent("test-agent")
        val run = runs.value?.firstOrNull()
        assertNotNull("Run should exist in database", run)

        run?.let {
            assertEquals("complete", it.status)
            assertEquals(14, it.currentPhase)
            assertNotNull(it.completedAt)

            val phases = dao.getPhaseResultsForRun(it.runId)
            assertEquals(14, phases.size)
            assertTrue("All phases should be complete", phases.all { p -> p.status == "complete" })

            val events = dao.getEventsForRun(it.runId)
            assertTrue("Should have at least 14 events (cycle_created + 14 phases)", events.size >= 15)

            // Verify hash chain integrity
            for (i in 1 until events.size) {
                assertEquals(
                    "Event $i hash chain broken",
                    events[i - 1].eventHash,
                    events[i].previousEventHash
                )
            }
        }
    }

    @Test
    fun testEventHashChainIsValid() = runBlocking {
        val run = runtime.createCycle(
            agentId = "hash-test",
            objective = "Hash test",
            authorizationBoundary = "test",
            successCriteria = emptyList()
        )

        runtime.startPhase(run.runId, EDDEPhase.ActivePerceive)
        runtime.completePhase(run.runId, EDDEPhase.ActivePerceive, "test output")

        val events = dao.getEventsForRun(run.runId)
        assertTrue(events.size >= 3) // cycle_created, phase_started, phase_completed

        // Verify each event has non-empty hash
        events.forEach { event ->
            assertTrue("Event hash should not be empty", event.eventHash.isNotBlank())
            assertTrue("Event hash should be 64 chars (SHA-256 hex)", event.eventHash.length == 64)
        }

        // Verify hash chain
        for (i in 1 until events.size) {
            assertEquals(events[i - 1].eventHash, events[i].previousEventHash)
        }
    }

    @Test
    fun testCheckpointBeforeLLMPhase() = runBlocking {
        val run = runtime.createCycle(
            agentId = "checkpoint-test",
            objective = "Checkpoint test",
            authorizationBoundary = "test",
            successCriteria = emptyList()
        )

        runtime.requestCheckpoint(run.runId, "cp-test", "test_action", "rollback_plan")
        val checkpoints = dao.getCheckpointsForRun(run.runId)
        assertEquals(1, checkpoints.size)
        assertEquals("pending", checkpoints[0].authorizationStatus)

        runtime.authorizeCheckpoint("cp-test")
        val updated = dao.getCheckpointsForRun(run.runId)
        assertEquals("granted", updated[0].authorizationStatus)
    }
}
