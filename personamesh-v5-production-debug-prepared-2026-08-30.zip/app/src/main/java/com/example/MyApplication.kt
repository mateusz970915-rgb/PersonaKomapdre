package com.example

import android.app.Application
import androidx.work.Configuration
import androidx.work.WorkManager

class MyApplication : Application(), Configuration.Provider {
    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
}
