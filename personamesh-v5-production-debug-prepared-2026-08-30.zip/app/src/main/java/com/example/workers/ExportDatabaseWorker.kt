package com.example.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.data.AppDatabase
import com.example.data.edde.*
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class ExportDatabaseWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val database = AppDatabase.getDatabase(applicationContext)
            val exportRoot = JSONObject()

            // 1. Core Colony Data
            exportRoot.put("agents", exportAgents(database))
            exportRoot.put("missions", exportMissions(database))
            exportRoot.put("subtasks", exportSubTasks(database))
            exportRoot.put("decisions", exportDecisions(database))
            exportRoot.put("memories", exportMemories(database))
            exportRoot.put("council_messages", exportCouncilMessages(database))
            exportRoot.put("data_access_requests", exportDataAccessRequests(database))

            // 2. EDDE+ Runtime Data (6 tables)
            exportRoot.put("edde_pipeline_runs", exportEddePipelineRuns(database))
            exportRoot.put("edde_phase_results", exportEddePhaseResults(database))
            exportRoot.put("edde_events", exportEddeEvents(database))
            exportRoot.put("edde_evidence", exportEddeEvidence(database))
            exportRoot.put("edde_predictions", exportEddePredictions(database))
            exportRoot.put("edde_checkpoints", exportEddeCheckpoints(database))

            // 3. Telemetry & Audit
            exportRoot.put("llm_telemetry", exportLlmTelemetry(database))
            exportRoot.put("mesh_telemetry", exportMeshTelemetry(database))
            exportRoot.put("hallucination_audits", exportHallucinationAudits(database))
            exportRoot.put("vector_embeddings", exportVectorEmbeddings(database))
            exportRoot.put("self_healing_proposals", exportSelfHealingProposals(database))

            // 4. Workflow & Rules
            exportRoot.put("workflow_dags", exportWorkflowDags(database))
            exportRoot.put("rule_nodes", exportRuleNodes(database))
            exportRoot.put("rule_connections", exportRuleConnections(database))

            // 5. User Data
            exportRoot.put("calendar_events", exportCalendarEvents(database))
            exportRoot.put("sleep_records", exportSleepRecords(database))
            exportRoot.put("finance_transactions", exportFinanceTransactions(database))
            exportRoot.put("flashcards", exportFlashcards(database))
            exportRoot.put("badges", exportBadges(database))
            exportRoot.put("agent_milestones", exportAgentMilestones(database))
            exportRoot.put("inter_agent_messages", exportInterAgentMessages(database))
            exportRoot.put("subscriptions", exportSubscriptions(database))
            exportRoot.put("persona_agents", exportPersonaAgents(database))

            val exportDir = File(applicationContext.cacheDir, "exports")
            if (!exportDir.exists()) exportDir.mkdirs()

            val timestamp = System.currentTimeMillis()
            val exportFile = File(exportDir, "personamesh_full_backup_$timestamp.json")
            exportFile.writeText(exportRoot.toString(2))

            showNotification(exportFile.name)
            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure()
        }
    }

    // --- Core Colony ---
    private suspend fun exportAgents(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.agentDao().getAllAgents().first().forEach { a ->
            arr.put(JSONObject().apply {
                put("id", a.id); put("name", a.name); put("type", a.type)
                put("role", a.role); put("status", a.status); put("permissions", a.permissions)
                put("iconName", a.iconName); put("traits", a.traits)
                put("systemPrompt", a.systemPrompt); put("autonomyLevel", a.autonomyLevel)
                put("personaDescription", a.personaDescription); put("avatarUrl", a.avatarUrl)
                put("configurationJson", a.configurationJson); put("isFavorite", a.isFavorite)
            })
        }
        return arr
    }

    private suspend fun exportMissions(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllMissions().first().forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id); put("goal", m.goal); put("status", m.status)
                put("createdAt", m.createdAt); put("completedAt", m.completedAt)
            })
        }
        return arr
    }

    private suspend fun exportSubTasks(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllSubTasks().first().forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id); put("missionId", t.missionId); put("assignedAgent", t.assignedAgent)
                put("description", t.description); put("status", t.status); put("actionType", t.actionType)
            })
        }
        return arr
    }

    private suspend fun exportDecisions(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllDecisions().first().forEach { d ->
            arr.put(JSONObject().apply {
                put("id", d.id); put("agentName", d.agentName); put("actionDescription", d.actionDescription)
                put("dataUsed", d.dataUsed); put("confidenceLevel", d.confidenceLevel)
                put("dissentingOpinions", d.dissentingOpinions); put("timestamp", d.timestamp)
            })
        }
        return arr
    }

    private suspend fun exportMemories(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllMemories().first().forEach { m ->
            arr.put(JSONObject().apply { put("id", m.id); put("content", m.content); put("timestamp", m.timestamp) })
        }
        return arr
    }

    private suspend fun exportCouncilMessages(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllCouncilMessages().first().forEach { c ->
            arr.put(JSONObject().apply {
                put("id", c.id); put("agentName", c.agentName); put("content", c.content); put("timestamp", c.timestamp)
            })
        }
        return arr
    }

    private suspend fun exportDataAccessRequests(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllDataAccessRequests().first().forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id); put("agentName", r.agentName); put("dataType", r.dataType)
                put("isPolicyViolation", r.isPolicyViolation); put("violationReason", r.violationReason)
                put("requiresUserApproval", r.requiresUserApproval); put("approvalStatus", r.approvalStatus)
            })
        }
        return arr
    }

    // --- EDDE+ Runtime (6 tables) ---
    private suspend fun exportEddePipelineRuns(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.eddeDao().getRecentPipelineRuns().first().forEach { r ->
            arr.put(JSONObject().apply {
                put("runId", r.runId); put("agentId", r.agentId); put("objective", r.objective)
                put("status", r.status); put("currentPhase", r.currentPhase)
                put("createdAt", r.createdAt); put("completedAt", r.completedAt)
            })
        }
        return arr
    }

    private suspend fun exportEddePhaseResults(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        // We need a way to get all phase results — iterate through all runs
        db.eddeDao().getRecentPipelineRuns().first().forEach { run ->
            db.eddeDao().getPhaseResultsForRun(run.runId).forEach { p ->
                arr.put(JSONObject().apply {
                    put("phaseId", p.phaseId); put("runId", p.runId); put("phaseNumber", p.phaseNumber)
                    put("phaseName", p.phaseName); put("status", p.status)
                    put("executionTimeMs", p.executionTimeMs); put("tokensUsed", p.tokensUsed)
                })
            }
        }
        return arr
    }

    private suspend fun exportEddeEvents(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.eddeDao().getRecentPipelineRuns().first().forEach { run ->
            db.eddeDao().getEventsForRun(run.runId).forEach { e ->
                arr.put(JSONObject().apply {
                    put("eventId", e.eventId); put("runId", e.runId); put("eventType", e.eventType)
                    put("sequence", e.sequence); put("eventHash", e.eventHash); put("timestamp", e.timestamp)
                })
            }
        }
        return arr
    }

    private suspend fun exportEddeEvidence(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.eddeDao().getRecentPipelineRuns().first().forEach { run ->
            db.eddeDao().getEvidenceForRun(run.runId).forEach { ev ->
                arr.put(JSONObject().apply {
                    put("evidenceId", ev.evidenceId); put("runId", ev.runId); put("kind", ev.kind)
                    put("content", ev.content.take(500)); put("phaseName", ev.phaseName)
                })
            }
        }
        return arr
    }

    private suspend fun exportEddePredictions(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.eddeDao().getRecentPipelineRuns().first().forEach { run ->
            db.eddeDao().getPredictionsForRun(run.runId).forEach { p ->
                arr.put(JSONObject().apply {
                    put("predictionId", p.predictionId); put("runId", p.runId)
                    put("expected", p.expected); put("observed", p.observed); put("result", p.result)
                })
            }
        }
        return arr
    }

    private suspend fun exportEddeCheckpoints(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.eddeDao().getRecentPipelineRuns().first().forEach { run ->
            db.eddeDao().getCheckpointsForRun(run.runId).forEach { cp ->
                arr.put(JSONObject().apply {
                    put("checkpointId", cp.checkpointId); put("runId", cp.runId)
                    put("action", cp.action); put("rollback", cp.rollback)
                    put("authorizationStatus", cp.authorizationStatus)
                })
            }
        }
        return arr
    }

    // --- Telemetry & Audit ---
    private suspend fun exportLlmTelemetry(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllLlmTelemetry().first().forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id); put("agentName", t.agentName); put("endpoint", t.endpoint)
                put("latencyMs", t.latencyMs); put("success", t.success); put("timestamp", t.timestamp)
            })
        }
        return arr
    }

    private suspend fun exportMeshTelemetry(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllMeshTelemetry().first().forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id); put("agentName", t.agentName); put("eventType", t.eventType)
                put("payload", t.payload); put("timestamp", t.timestamp)
            })
        }
        return arr
    }

    private suspend fun exportHallucinationAudits(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllHallucinationAuditLogs().first().forEach { a ->
            arr.put(JSONObject().apply {
                put("id", a.id); put("promptText", a.promptText); put("responseText", a.responseText)
                put("factCheckScore", a.factCheckScore); put("verdict", a.verdict)
            })
        }
        return arr
    }

    private suspend fun exportVectorEmbeddings(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllVectorEmbeddingLogs().first().forEach { v ->
            arr.put(JSONObject().apply {
                put("id", v.id); put("sourceText", v.sourceText); put("tag", v.tag)
                put("similarityScore", v.similarityScore)
            })
        }
        return arr
    }

    private suspend fun exportSelfHealingProposals(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllSelfHealingProposals().first().forEach { p ->
            arr.put(JSONObject().apply {
                put("id", p.id); put("missionId", p.missionId); put("errorLogSnippet", p.errorLogSnippet)
                put("rootCauseAnalysis", p.rootCauseAnalysis); put("proposedCodeFix", p.proposedCodeFix)
            })
        }
        return arr
    }

    // --- Workflow & Rules ---
    private suspend fun exportWorkflowDags(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllWorkflowDags().first().forEach { w ->
            arr.put(JSONObject().apply {
                put("id", w.id); put("name", w.name); put("jsonPayload", w.jsonPayload)
            })
        }
        return arr
    }

    private suspend fun exportRuleNodes(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllRuleNodes().first().forEach { n ->
            arr.put(JSONObject().apply {
                put("id", n.id); put("posX", n.posX); put("posY", n.posY)
                put("nodeType", n.nodeType); put("text", n.text)
            })
        }
        return arr
    }

    private suspend fun exportRuleConnections(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllRuleConnections().first().forEach { c ->
            arr.put(JSONObject().apply { put("fromId", c.fromId); put("toId", c.toId) })
        }
        return arr
    }

    // --- User Data ---
    private suspend fun exportCalendarEvents(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllCalendarEvents().first().forEach { e ->
            arr.put(JSONObject().apply {
                put("id", e.id); put("title", e.title); put("startTime", e.startTime); put("endTime", e.endTime)
            })
        }
        return arr
    }

    private suspend fun exportSleepRecords(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllSleepRecords().first().forEach { s ->
            arr.put(JSONObject().apply {
                put("id", s.id); put("date", s.date); put("hours", s.hours); put("quality", s.quality)
            })
        }
        return arr
    }

    private suspend fun exportFinanceTransactions(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllFinanceTransactions().first().forEach { f ->
            arr.put(JSONObject().apply {
                put("id", f.id); put("description", f.description); put("amount", f.amount); put("category", f.category)
            })
        }
        return arr
    }

    private suspend fun exportFlashcards(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllFlashcards().first().forEach { f ->
            arr.put(JSONObject().apply {
                put("id", f.id); put("front", f.front); put("back", f.back); put("category", f.category)
            })
        }
        return arr
    }

    private suspend fun exportBadges(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllBadges().first().forEach { b ->
            arr.put(JSONObject().apply {
                put("id", b.id); put("name", b.name); put("description", b.description)
                put("category", b.category); put("iconName", b.iconName); put("progress", b.progress)
                put("maxProgress", b.maxProgress); put("isUnlocked", b.isUnlocked)
            })
        }
        return arr
    }

    private suspend fun exportAgentMilestones(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllAgentMilestones().first().forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id); put("name", m.name); put("description", m.description)
                put("category", m.category); put("progress", m.progress); put("maxProgress", m.maxProgress)
            })
        }
        return arr
    }

    private suspend fun exportInterAgentMessages(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllInterAgentMessages().first().forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id); put("senderAgentName", m.senderAgentName); put("senderRole", m.senderRole)
                put("content", m.content); put("topic", m.topic); put("timestamp", m.timestamp)
            })
        }
        return arr
    }

    private suspend fun exportSubscriptions(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.colonyDao().getAllSubscriptions().first().forEach { s ->
            arr.put(JSONObject().apply {
                put("id", s.id); put("name", s.name); put("cost", s.cost); put("renewalDate", s.renewalDate)
            })
        }
        return arr
    }

    private suspend fun exportPersonaAgents(db: AppDatabase): JSONArray {
        val arr = JSONArray()
        db.agentDao().getAllPersonaAgents().first().forEach { p ->
            arr.put(JSONObject().apply {
                put("id", p.id); put("agentName", p.agentName); put("characterTraits", p.characterTraits)
                put("operationalRole", p.operationalRole); put("communicationStyle", p.communicationStyle)
            })
        }
        return arr
    }

    private fun showNotification(filename: String) {
        val notificationManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "export_reminder_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Backup Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Reminders to export your data" }
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            data = Uri.parse("colony://settings")
        }
        val pendingIntent = PendingIntent.getActivity(
            applicationContext, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Data Backup Complete")
            .setContentText("Full backup exported: $filename (26 tables)")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(1003, notification)
    }
}
