package com.example.usecase

import android.content.Context
import com.example.network.AILlmClient
import com.example.ui.DagEdgeData
import com.example.ui.DagNodeData

/**
 * Realne wykonanie DAG przez LLM.
 * Przechodzi węzły topologicznie, wywołuje LLM dla każdego, propaguje wyniki.
 */
class WorkflowExecutionUseCase {

    data class NodeResult(
        val nodeId: String,
        val agentName: String,
        val input: String,
        val output: String,
        val status: String // success / failed
    )

    data class ExecutionReport(
        val results: List<NodeResult>,
        val finalOutput: String,
        val completedNodes: Int,
        val failedNodes: Int
    )

    suspend fun executeDag(
        context: Context,
        dagName: String,
        nodes: List<DagNodeData>,
        edges: List<DagEdgeData>,
        initialInput: String = "Execute the workflow: $dagName"
    ): ExecutionReport {
        val sorted = topologicalSort(nodes, edges)
        val results = mutableListOf<NodeResult>()
        var currentInput = initialInput
        var failed = 0

        for (node in sorted) {
            val nodeEdges = edges.filter { it.toId == node.id }
            val parentOutputs = nodeEdges.mapNotNull { edge ->
                results.find { it.nodeId == edge.fromId }?.output
            }

            val input = if (parentOutputs.isNotEmpty()) parentOutputs.joinToString("\n") else currentInput

            val prompt = """
                You are agent "${node.agentName}" with role "${node.role}".
                
                INPUT FROM PREVIOUS NODES:
                $input
                
                TASK: Process the input according to your role and produce output for the next node.
                Be concise (2-4 sentences). If you detect an error, start with "ERROR:".
            """.trimIndent()

            val output = try {
                AILlmClient.generateContent(context, prompt)
            } catch (e: Exception) {
                failed++
                results.add(NodeResult(node.id, node.agentName, input, "ERROR: ${e.message}", "failed"))
                continue
            }

            val status = if (output.startsWith("ERROR:")) {
                failed++
                "failed"
            } else "success"

            results.add(NodeResult(node.id, node.agentName, input, output, status))
            currentInput = output
        }

        val finalOutput = results.lastOrNull()?.output ?: "No output"
        return ExecutionReport(results, finalOutput, results.count { it.status == "success" }, failed)
    }

    private fun topologicalSort(nodes: List<DagNodeData>, edges: List<DagEdgeData>): List<DagNodeData> {
        val inDegree = nodes.associate { it.id to 0 }.toMutableMap()
        val adj = nodes.associate { it.id to mutableListOf<String>() }.toMutableMap()

        edges.forEach { edge ->
            adj[edge.fromId]?.add(edge.toId)
            inDegree[edge.toId] = (inDegree[edge.toId] ?: 0) + 1
        }

        val queue = ArrayDeque(nodes.filter { (inDegree[it.id] ?: 0) == 0 }.map { it.id })
        val sorted = mutableListOf<DagNodeData>()

        while (queue.isNotEmpty()) {
            val id = queue.removeFirst()
            val node = nodes.find { it.id == id } ?: continue
            sorted.add(node)
            adj[id]?.forEach { neighbor ->
                inDegree[neighbor] = (inDegree[neighbor] ?: 0) - 1
                if ((inDegree[neighbor] ?: 0) == 0) queue.add(neighbor)
            }
        }

        return if (sorted.size == nodes.size) sorted else nodes
    }
}
