package com.example.usecase

import android.content.Context
import com.example.network.AILlmClient
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Uproszczony Monte Carlo Tree Search z LLM jako funkcją oceny.
 * W MVP: 2 rollouts per node, LLM ocenia stan po każdym ruchu.
 */
class MctsUseCase {

    data class MctsNode(
        val state: String,
        val parent: MctsNode? = null,
        val action: String = "root",
        val children: MutableList<MctsNode> = mutableListOf(),
        var visits: Int = 0,
        var score: Float = 0f
    )

    data class MctsResult(
        val bestAction: String,
        val bestScore: Float,
        val treeDepth: Int,
        val nodesExplored: Int,
        val reasoning: String
    )

    suspend fun search(
        context: Context,
        problem: String,
        possibleActions: List<String>,
        iterations: Int = 6
    ): MctsResult {
        val root = MctsNode(state = problem)

        // Expand root with all possible actions
        possibleActions.forEach { action ->
            root.children.add(MctsNode(state = "$problem -> $action", parent = root, action = action))
        }

        // MCTS iterations
        repeat(iterations) {
            val node = select(root)
            val expanded = if (node.children.isEmpty() && node.visits > 0) {
                expand(context, node, possibleActions)
            } else node
            val reward = rollout(context, expanded)
            backpropagate(expanded, reward)
        }

        val best = root.children.maxByOrNull { it.score / (it.visits.coerceAtLeast(1)) }
            ?: root.children.firstOrNull()
            ?: return MctsResult("none", 0f, 0, 0, "No actions available")

        val reasoning = buildString {
            append("Explored ${root.children.sumOf { it.visits }} nodes. ")
            append("Best action: ${best.action} with avg score ${best.score / best.visits}. ")
            append("Alternatives: ${root.children.filter { it != best }.joinToString { "${it.action}(${it.visits})" }}")
        }

        return MctsResult(
            bestAction = best.action,
            bestScore = best.score / best.visits.coerceAtLeast(1),
            treeDepth = computeDepth(root),
            nodesExplored = root.children.sumOf { it.visits },
            reasoning = reasoning
        )
    }

    private fun select(node: MctsNode): MctsNode {
        if (node.children.isEmpty()) return node
        return node.children.maxByOrNull { ucb1(it) }?.let { select(it) } ?: node
    }

    private fun ucb1(node: MctsNode): Float {
        if (node.visits == 0) return Float.MAX_VALUE
        val parentVisits = node.parent?.visits?.toFloat() ?: 1f
        return (node.score / node.visits) + 1.41f * sqrt(ln(parentVisits) / node.visits)
    }

    private suspend fun expand(context: Context, node: MctsNode, actions: List<String>): MctsNode {
        if (node.children.isNotEmpty()) return node
        actions.shuffled().take(2).forEach { action ->
            node.children.add(MctsNode(state = "${node.state} -> $action", parent = node, action = action))
        }
        return node.children.firstOrNull() ?: node
    }

    private suspend fun rollout(context: Context, node: MctsNode): Float {
        val prompt = """
            Evaluate this state in a decision-making process:
            STATE: ${node.state}
            
            Rate how promising this state is on a scale of 0.0 to 1.0.
            Return ONLY a number between 0.0 and 1.0, nothing else.
        """.trimIndent()

        return try {
            val response = AILlmClient.generateContent(context, prompt)
            response.trim().take(4).toFloatOrNull()?.coerceIn(0f, 1f) ?: 0.5f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun backpropagate(node: MctsNode, reward: Float) {
        var current: MctsNode? = node
        while (current != null) {
            current.visits += 1
            current.score += reward
            current = current.parent
        }
    }

    private fun computeDepth(node: MctsNode, depth: Int = 0): Int {
        return if (node.children.isEmpty()) depth else node.children.maxOf { computeDepth(it, depth + 1) }
    }
}
