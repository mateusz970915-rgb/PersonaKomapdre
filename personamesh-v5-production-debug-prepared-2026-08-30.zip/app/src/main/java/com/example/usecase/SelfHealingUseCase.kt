package com.example.usecase

import android.content.Context
import com.example.network.AILlmClient

/**
 * Realna samonaprawa kodu przez LLM.
 * Analizuje stack trace / log błędu i generuje propozycję fixu.
 */
class SelfHealingUseCase {

    data class HealingResult(
        val rootCause: String,
        val proposedFix: String,
        val confidence: Float,
        val explanation: String
    )

    suspend fun analyzeError(
        context: Context,
        errorLog: String,
        codebaseContext: String = ""
    ): HealingResult {
        val prompt = """
            You are a senior Android/Kotlin code reviewer. Analyze the following error log and propose a fix.
            
            ERROR LOG:
            ```
            $errorLog
            ```
            
            ${if (codebaseContext.isNotBlank()) "CODEBASE CONTEXT:\n```\n$codebaseContext\n```" else ""}
            
            Task:
            1. Identify the root cause of the error.
            2. Propose a concrete code fix.
            3. Explain why this fix works.
            
            Return your answer in this exact format:
            ROOT_CAUSE: <one sentence>
            FIX: <code snippet>
            CONFIDENCE: <0.0-1.0>
            EXPLANATION: <2-3 sentences>
        """.trimIndent()

        val response = try {
            AILlmClient.generateContent(context, prompt)
        } catch (e: Exception) {
            return HealingResult(
                rootCause = "Analysis failed: ${e.message}",
                proposedFix = "",
                confidence = 0.0f,
                explanation = ""
            )
        }

        return parseHealingResult(response)
    }

    private fun parseHealingResult(response: String): HealingResult {
        val rootCause = extractTag(response, "ROOT_CAUSE") ?: "Unknown root cause"
        val fix = extractTag(response, "FIX") ?: "No fix proposed"
        val confidence = extractTag(response, "CONFIDENCE")?.toFloatOrNull() ?: 0.5f
        val explanation = extractTag(response, "EXPLANATION") ?: "No explanation provided"

        return HealingResult(rootCause, fix, confidence, explanation)
    }

    private fun extractTag(text: String, tag: String): String? {
        val regex = Regex("$tag:\\s*(.*?)(?=\\n[A-Z_]+:|\\z)", RegexOption.DOT_MATCHES_ALL)
        return regex.find(text)?.groupValues?.get(1)?.trim()
    }
}
