package com.example.usecase

import kotlin.math.sqrt

/**
 * Realne wyszukiwanie wektorowe bez zewnętrznego API.
 * Używa TF-IDF + cosine similarity na bag-of-words.
 * W MVP: tokenizacja słów, wektory TF-IDF, ranking cosine.
 */
class VectorSearchUseCase {

    data class SearchResult(
        val text: String,
        val tag: String,
        val similarity: Float
    )

    fun search(query: String, documents: List<Pair<String, String>>): List<SearchResult> {
        if (query.isBlank()) return documents.map { SearchResult(it.first, it.second, 0.85f) }

        val queryTokens = tokenize(query)
        val docTokens = documents.map { tokenize(it.first) }
        val allTokens = (queryTokens + docTokens.flatten()).distinct()

        val idf = computeIdf(docTokens + listOf(queryTokens), allTokens)
        val queryVector = computeTfIdf(queryTokens, allTokens, idf)

        return documents.mapIndexed { index, (text, tag) ->
            val docVector = computeTfIdf(docTokens[index], allTokens, idf)
            val similarity = cosineSimilarity(queryVector, docVector)
            SearchResult(text, tag, similarity)
        }.sortedByDescending { it.similarity }
    }

    private fun tokenize(text: String): List<String> {
        return text.lowercase()
            .replace(Regex("[^a-ząćęłńóśźż0-9\\s]"), " ")
            .split(Regex("\\s+"))
            .filter { it.length > 2 }
            .map { stem(it) }
    }

    private fun stem(word: String): String {
        // Prosty stemming PL/EN: obcinanie końcówek
        val suffixes = listOf("ing", "tion", "sion", "ness", "ment", "able", "ible", "ly", "ed", "ies", "ów", "ach", "ami", "emi", "om", "ego", "emu", "iej", "ich", "imi")
        for (suf in suffixes) {
            if (word.endsWith(suf) && word.length > suf.length + 3) {
                return word.dropLast(suf.length)
            }
        }
        return word
    }

    private fun computeIdf(docs: List<List<String>>, allTokens: List<String>): Map<String, Float> {
        val n = docs.size.toFloat()
        return allTokens.associateWith { token ->
            val df = docs.count { it.contains(token) }.toFloat().coerceAtLeast(1f)
            kotlin.math.ln(n / df)
        }
    }

    private fun computeTfIdf(tokens: List<String>, allTokens: List<String>, idf: Map<String, Float>): FloatArray {
        val tf = tokens.groupingBy { it }.eachCount().mapValues { it.value.toFloat() / tokens.size }
        return FloatArray(allTokens.size) { i ->
            val token = allTokens[i]
            (tf[token] ?: 0f) * (idf[token] ?: 0f)
        }
    }

    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        var dot = 0f
        var normA = 0f
        var normB = 0f
        for (i in a.indices) {
            dot += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        return if (normA == 0f || normB == 0f) 0f else dot / (sqrt(normA) * sqrt(normB))
    }
}
