package com.example.usecase

import android.content.Context
import com.example.network.AILlmClient
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * Realny fact-checking przez LLM.
 * Dzieli odpowiedź na claims i weryfikuje każdy osobno.
 */
class HallucinationUseCase {

    data class ClaimVerification(
        val claim: String,
        val verdict: String, // verified / unverified / false
        val confidence: Float,
        val explanation: String
    )

    data class AuditResult(
        val overallScore: Float,
        val verdict: String,
        val claims: List<ClaimVerification>
    )

    suspend fun audit(context: Context, prompt: String, response: String): AuditResult {
        val factCheckPrompt = """
            You are a fact-checking auditor. Analyze the following AI response for factual accuracy.
            
            USER PROMPT: $prompt
            AI RESPONSE: $response
            
            Task:
            1. Extract each factual claim from the AI response.
            2. Verify each claim against your knowledge.
            3. Return ONLY a JSON array in this exact format:
            [
              {
                "claim": "exact claim text",
                "verdict": "verified" | "unverified" | "false",
                "confidence": 0.0-1.0,
                "explanation": "why this verdict"
              }
            ]
            
            Rules:
            - If a claim contains specific numbers, dates, or technical facts, verify carefully.
            - "verified" = you know this is true.
            - "false" = you know this is incorrect.
            - "unverified" = you cannot confirm or deny.
            - Be strict. When in doubt, mark as "unverified".
            - Return ONLY the JSON array, no other text.
        """.trimIndent()

        val llmResponse = try {
            AILlmClient.generateContent(context, factCheckPrompt)
        } catch (e: Exception) {
            return AuditResult(
                overallScore = 0.0f,
                verdict = "Audit Failed: ${e.message}",
                claims = emptyList()
            )
        }

        val claims = parseClaims(llmResponse)
        val overallScore = if (claims.isEmpty()) 0.0f else
            claims.count { it.verdict == "verified" }.toFloat() / claims.size

        val verdict = when {
            claims.any { it.verdict == "false" } -> "Contains False Information"
            overallScore > 0.8f -> "Fakt Zweryfikowany"
            overallScore > 0.5f -> "Częściowo Zweryfikowany"
            else -> "Możliwa Halucynacja"
        }

        return AuditResult(overallScore, verdict, claims)
    }

    private fun parseClaims(response: String): List<ClaimVerification> {
        val jsonStart = response.indexOf('[')
        val jsonEnd = response.lastIndexOf(']')
        if (jsonStart < 0 || jsonEnd < 0 || jsonEnd <= jsonStart) return emptyList()

        val jsonStr = response.substring(jsonStart, jsonEnd + 1)
        return try {
            Json.parseToJsonElement(jsonStr).jsonArray.map { elem ->
                val obj = elem.jsonObject
                ClaimVerification(
                    claim = obj["claim"]?.jsonPrimitive?.content ?: "",
                    verdict = obj["verdict"]?.jsonPrimitive?.content ?: "unverified",
                    confidence = obj["confidence"]?.jsonPrimitive?.content?.toFloatOrNull() ?: 0.5f,
                    explanation = obj["explanation"]?.jsonPrimitive?.content ?: ""
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
