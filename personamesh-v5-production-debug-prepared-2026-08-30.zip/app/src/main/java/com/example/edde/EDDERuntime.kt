package com.example.edde

import com.example.data.edde.*
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.security.MessageDigest
import java.util.UUID

class EDDERuntime(
    private val dao: EddeDao,
    private val json: Json = Json { ignoreUnknownKeys = true }
) {
    private val sha256 = MessageDigest.getInstance("SHA-256")

    private fun hashString(input: String): String {
        return sha256.digest(input.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private fun eventHash(runId: String, type: String, payload: String, sequence: Int, previousHash: String, timestamp: Long): String {
        val body = buildJsonObject {
            put("type", type)
            put("payload", payload)
            put("sequence", sequence)
            put("eventId", "$runId:${sequence.toString().padStart(6, '0')}")
            put("previousEventHash", previousHash)
            put("runId", runId)
            put("actor", "SANRuntime")
            put("timestamp", timestamp)
        }.toString()
        return hashString(body)
    }

    private fun evidenceId(content: String): String {
        return "ev-" + hashString(content).take(16)
    }

    suspend fun createCycle(
        runId: String = UUID.randomUUID().toString(),
        agentId: String,
        objective: String,
        authorizationBoundary: String,
        successCriteria: List<String>
    ): EddePipelineRun {
        val run = EddePipelineRun(
            runId = runId,
            agentId = agentId,
            objective = objective,
            authorizationBoundary = authorizationBoundary,
            successCriteriaJson = json.encodeToString(successCriteria)
        )
        dao.insertPipelineRun(run)
        EDDEPhase.ALL.forEach { phase ->
            dao.insertPhaseResult(
                EddePhaseResult(
                    phaseId = "$runId:${phase.number}",
                    runId = runId,
                    phaseNumber = phase.number,
                    phaseName = phase.name
                )
            )
        }
        appendEvent(runId, "cycle_created", buildJsonObject {
            put("runId", runId)
            put("objective", objective)
        }.toString())
        return run
    }

    suspend fun startPhase(runId: String, phase: EDDEPhase) {
        val phaseResult = dao.getPhaseResult(runId, phase.number)
            ?: throw IllegalStateException("Phase ${phase.name} not found for run $runId")
        if (phaseResult.status != "pending") {
            throw IllegalStateException("Phase ${phase.name} is not pending (current: ${phaseResult.status})")
        }
        val allPhases = dao.getPhaseResultsForRun(runId)
        val priorIncomplete = allPhases.filter { it.phaseNumber < phase.number && it.status != "complete" }
        if (priorIncomplete.isNotEmpty()) {
            throw IllegalStateException("Prior phases incomplete: ${priorIncomplete.map { it.phaseName }}")
        }
        dao.insertPhaseResult(phaseResult.copy(status = "active"))
        appendEvent(runId, "phase_started", buildJsonObject {
            put("phase", phase.name)
        }.toString())
    }

    suspend fun completePhase(runId: String, phase: EDDEPhase, output: String, tokensUsed: Int = 0) {
        val phaseResult = dao.getPhaseResult(runId, phase.number)
            ?: throw IllegalStateException("Phase ${phase.name} not found")
        if (phaseResult.status != "active") {
            throw IllegalStateException("Phase ${phase.name} is not active")
        }
        val evidenceId = addEvidence(runId, kind = "phase_output", content = output, phaseName = phase.name)
        val elapsed = System.currentTimeMillis() - phaseResult.timestamp
        dao.insertPhaseResult(phaseResult.copy(
            status = "complete",
            outputSnapshot = output,
            executionTimeMs = elapsed,
            tokensUsed = tokensUsed,
            evidenceRefsJson = json.encodeToString(listOf(evidenceId))
        ))
        appendEvent(runId, "phase_completed", buildJsonObject {
            put("phase", phase.name)
            put("evidenceId", evidenceId)
        }.toString())
        dao.updatePipelineRunStatus(runId, "active", phase.number, null)
    }

    suspend fun blockPhase(runId: String, phase: EDDEPhase, reason: String) {
        val phaseResult = dao.getPhaseResult(runId, phase.number)
            ?: throw IllegalStateException("Phase ${phase.name} not found")
        if (phaseResult.status != "active") {
            throw IllegalStateException("Phase ${phase.name} is not active")
        }
        dao.insertPhaseResult(phaseResult.copy(status = "blocked", errorMessage = reason))
        val allPhases = dao.getPhaseResultsForRun(runId)
        allPhases.filter { it.phaseNumber > phase.number && it.status == "pending" }.forEach {
            dao.insertPhaseResult(it.copy(status = "not_run"))
        }
        dao.updatePipelineRunStatus(runId, "blocked", phase.number, System.currentTimeMillis())
        appendEvent(runId, "phase_blocked", buildJsonObject {
            put("phase", phase.name)
            put("reason", reason)
        }.toString())
    }

    suspend fun addEvidence(runId: String, kind: String, content: String, phaseName: String? = null, isExternal: Boolean = false): String {
        val eid = evidenceId(content)
        val evidence = EddeEvidence(
            evidenceId = eid,
            runId = runId,
            kind = kind,
            content = content,
            phaseName = phaseName,
            isExternal = isExternal
        )
        dao.insertEvidence(evidence)
        appendEvent(runId, "evidence_added", buildJsonObject {
            put("evidenceId", eid)
            put("kind", kind)
        }.toString())
        return eid
    }

    suspend fun recordPrediction(runId: String, predictionId: String, expected: String, failureSignal: String) {
        dao.insertPrediction(
            EddePrediction(
                runId = runId,
                predictionId = predictionId,
                expected = expected,
                failureSignal = failureSignal
            )
        )
        appendEvent(runId, "prediction_recorded", buildJsonObject {
            put("predictionId", predictionId)
            put("expected", expected)
            put("failureSignal", failureSignal)
        }.toString())
    }

    suspend fun recordObservation(runId: String, predictionId: String, observed: String) {
        val pred = dao.getPredictionsForRun(runId).find { it.predictionId == predictionId }
            ?: throw IllegalStateException("Unknown prediction: $predictionId")
        val result = if (observed == pred.expected) "matched" else "mismatch"
        dao.updateObservation(predictionId, observed, result)
        appendEvent(runId, "observation_recorded", buildJsonObject {
            put("predictionId", predictionId)
            put("observed", observed)
            put("result", result)
        }.toString())
    }

    suspend fun requestCheckpoint(runId: String, checkpointId: String, action: String, rollback: String) {
        dao.insertCheckpoint(
            EddeCheckpoint(
                runId = runId,
                checkpointId = checkpointId,
                action = action,
                rollback = rollback
            )
        )
        appendEvent(runId, "checkpoint_requested", buildJsonObject {
            put("checkpointId", checkpointId)
            put("action", action)
            put("rollback", rollback)
        }.toString())
    }

    suspend fun authorizeCheckpoint(checkpointId: String) {
        dao.updateCheckpointStatus(checkpointId, "granted")
    }

    private suspend fun appendEvent(runId: String, eventType: String, payload: String) {
        val maxSeq = dao.getMaxSequence(runId) ?: 0
        val sequence = maxSeq + 1
        val prevHash = dao.getEventsForRun(runId).lastOrNull()?.eventHash ?: ""
        val timestamp = System.currentTimeMillis()
        val eid = "$runId:${sequence.toString().padStart(6, '0')}"
        val hash = eventHash(runId, eventType, payload, sequence, prevHash, timestamp)
        dao.insertEvent(
            EddeEvent(
                eventId = eid,
                runId = runId,
                eventType = eventType,
                payloadJson = payload,
                sequence = sequence,
                previousEventHash = prevHash,
                eventHash = hash,
                timestamp = timestamp
            )
        )
    }

    suspend fun finalizeCycle(runId: String, verdict: String, evolutionJson: String) {
        val now = System.currentTimeMillis()
        dao.updatePipelineRunStatus(runId, verdict, 14, now)
        dao.updateEvolution(runId, evolutionJson)
    }

    suspend fun replayDynamicState(runId: String): Map<String, Any> {
        val events = dao.getEventsForRun(runId)
        val phases = EDDEPhase.ALL.associate {
            it.name to mutableMapOf<String, Any>("status" to "pending", "outputRefs" to mutableListOf<String>())
        }
        events.forEach { event ->
            when (event.eventType) {
                "phase_started" -> {
                    val pn = extractPhase(event.payloadJson)
                    (phases[pn] as? MutableMap<String, Any>)?.set("status", "active")
                }
                "phase_completed" -> {
                    val pn = extractPhase(event.payloadJson)
                    val evId = extractEvidenceId(event.payloadJson)
                    val p = phases[pn] as? MutableMap<String, Any> ?: return@forEach
                    p["status"] = "complete"
                    (p["outputRefs"] as MutableList<String>).add(evId)
                }
                "phase_blocked" -> {
                    val pn = extractPhase(event.payloadJson)
                    val p = phases[pn] as? MutableMap<String, Any> ?: return@forEach
                    p["status"] = "blocked"
                    val idx = EDDEPhase.ALL.indexOfFirst { it.name == pn }
                    EDDEPhase.ALL.drop(idx + 1).forEach { dep ->
                        val dp = phases[dep.name] as? MutableMap<String, Any> ?: return@forEach
                        if (dp["status"] == "pending") dp["status"] = "not_run"
                    }
                }
            }
        }
        return mapOf("phases" to phases, "eventCount" to events.size)
    }

    private fun extractPhase(payload: String): String {
        val key = "\"phase\":\""
        val start = payload.indexOf(key)
        if (start < 0) return ""
        val end = payload.indexOf("\"", start + key.length)
        return if (end > start) payload.substring(start + key.length, end) else ""
    }

    private fun extractEvidenceId(payload: String): String {
        val key = "\"evidenceId\":\""
        val start = payload.indexOf(key)
        if (start < 0) return ""
        val end = payload.indexOf("\"", start + key.length)
        return if (end > start) payload.substring(start + key.length, end) else ""
    }
}
