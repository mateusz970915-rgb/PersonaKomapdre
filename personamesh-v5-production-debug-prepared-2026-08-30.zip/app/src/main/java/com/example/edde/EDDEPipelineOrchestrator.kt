package com.example.edde

import android.content.Context
import com.example.data.edde.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

class EDDEPipelineOrchestrator(
    private val runtime: EDDERuntime,
    private val dao: EddeDao,
    private val json: Json = Json { ignoreUnknownKeys = true }
) {
    private val executors: Map<EDDEPhase, PhaseExecutor> = mapOf(
        EDDEPhase.ActivePerceive to ActivePerceiveExecutor(),
        EDDEPhase.ExtractEssenceState to ExtractEssenceStateExecutor(),
        EDDEPhase.MapDecomposeChallenge to MapDecomposeChallengeExecutor(),
        EDDEPhase.ArbitrateGoalsDirection to ArbitrateGoalsDirectionExecutor(),
        EDDEPhase.UpdateCausalModel to UpdateCausalModelExecutor(),
        EDDEPhase.SimulateForecastUncertainty to SimulateForecastUncertaintyExecutor(),
        EDDEPhase.GeneratePlansExperimentsRoutes to GeneratePlansExperimentsRoutesExecutor(),
        EDDEPhase.DecideRiskCostValues to DecideRiskCostValuesExecutor(),
        EDDEPhase.PlanExecuteCheckpoints to PlanExecuteCheckpointsExecutor(),
        EDDEPhase.ObserveOutcomesPredictionErrors to ObserveOutcomesPredictionErrorsExecutor(),
        EDDEPhase.EvaluateFalsifyVerify to EvaluateFalsifyVerifyExecutor(),
        EDDEPhase.ReflectDiagnose to ReflectDiagnoseExecutor(),
        EDDEPhase.ConsolidateMemoryProvenance to ConsolidateMemoryProvenanceExecutor(),
        EDDEPhase.EvolvePolicyCurriculumArchitecture to EvolvePolicyCurriculumArchitectureExecutor()
    )

    suspend fun runPipeline(
        context: Context,
        agentId: String,
        objective: String,
        authorizationBoundary: String = "device-local-read-only",
        successCriteria: List<String> = listOf(
            "Pipeline completes all 14 phases",
            "Phase 9 produces non-empty LLM response",
            "Phase 11 verification passes"
        )
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val run = runtime.createCycle(
                agentId = agentId,
                objective = objective,
                authorizationBoundary = authorizationBoundary,
                successCriteria = successCriteria
            )
            var lastOutput = ""
            var totalTokens = 0

            for (phase in EDDEPhase.ALL) {
                runtime.startPhase(run.runId, phase)

                if (phase == EDDEPhase.PlanExecuteCheckpoints) {
                    runtime.requestCheckpoint(
                        run.runId,
                        checkpointId = "cp-${phase.name}",
                        action = "llm_call_${phase.name}",
                        rollback = "abort_pipeline_and_return_error"
                    )
                    runtime.authorizeCheckpoint("cp-${phase.name}")
                }

                val input = PhaseInput(
                    runId = run.runId,
                    agentId = agentId,
                    objective = objective,
                    priorPhaseOutput = lastOutput
                )

                val output = executors[phase]?.execute(input, context)
                    ?: throw IllegalStateException("No executor for ${phase.name}")

                when (output.status) {
                    "complete" -> {
                        runtime.completePhase(run.runId, phase, output.text, output.tokensUsed)
                        lastOutput = output.text
                        totalTokens += output.tokensUsed
                        output.predictions.forEach { (expected, failureSignal) ->
                            runtime.recordPrediction(run.runId, "pred-${phase.name}-${System.currentTimeMillis()}", expected, failureSignal)
                        }
                    }
                    "failed" -> {
                        runtime.blockPhase(run.runId, phase, output.error ?: "Unknown failure")
                        return@withContext Result.failure(Exception("Phase ${phase.name} failed: ${output.error}"))
                    }
                    "blocked" -> {
                        runtime.blockPhase(run.runId, phase, output.error ?: "Blocked by checkpoint or policy")
                        return@withContext Result.failure(Exception("Phase ${phase.name} blocked"))
                    }
                }
                delay(50)
            }

            val evolutionJson = buildJsonObject {
                put("target", "EDDE+_Runtime")
                put("evidence", "[]")
                put("delta", "No_policy_change_in_MVP")
                put("adoptionState", "retained")
            }.toString()
            runtime.finalizeCycle(run.runId, "complete", evolutionJson)
            Result.success(lastOutput)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun resumePipeline(context: Context, runId: String, fromPhase: EDDEPhase): Result<String> =
        Result.failure(Exception("Resume not yet implemented in MVP. Restart pipeline instead."))

    suspend fun getCycleRecord(runId: String): EddePipelineRun? = dao.getPipelineRun(runId)
    suspend fun getPhaseDetails(runId: String): List<EddePhaseResult> = dao.getPhaseResultsForRun(runId)
    suspend fun getEvents(runId: String): List<EddeEvent> = dao.getEventsForRun(runId)
}
