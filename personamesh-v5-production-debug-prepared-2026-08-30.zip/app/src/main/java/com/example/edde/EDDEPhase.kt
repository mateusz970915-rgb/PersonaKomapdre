package com.example.edde

sealed class EDDEPhase(val number: Int, val name: String, val emoji: String, val description: String) {
    object ActivePerceive : EDDEPhase(1, "active_perceive", "\uD83C\uDF08", "Active Perceive")
    object ExtractEssenceState : EDDEPhase(2, "extract_essence_state", "\uD83D\uDC8E", "Extract Essence & State")
    object MapDecomposeChallenge : EDDEPhase(3, "map_decompose_challenge", "\uD83E\uDDE9", "Map, Decompose & Challenge Assumptions")
    object ArbitrateGoalsDirection : EDDEPhase(4, "arbitrate_goals_direction", "\uD83D\uDD25", "Arbitrate Goals & Select Direction")
    object UpdateCausalModel : EDDEPhase(5, "update_causal_model", "\uD83E\uDDE0", "Synthesize and Update the Causal World Model")
    object SimulateForecastUncertainty : EDDEPhase(6, "simulate_forecast_uncertainty", "\uD83D\uDD2E", "Simulate Counterfactuals & Forecast Uncertainty")
    object GeneratePlansExperimentsRoutes : EDDEPhase(7, "generate_plans_experiments_routes", "\uD83D\uDD00", "Generate Plans, Experiments & Tool Routes")
    object DecideRiskCostValues : EDDEPhase(8, "decide_risk_cost_values", "\u26A1", "Decide Under Risk, Cost & Values")
    object PlanExecuteCheckpoints : EDDEPhase(9, "plan_execute_checkpoints", "\uD83D\uDEE0\uFE0F", "Plan & Execute with Checkpoints")
    object ObserveOutcomesPredictionErrors : EDDEPhase(10, "observe_outcomes_prediction_errors", "\uD83D\uDC41\uFE0F", "Observe Outcomes & Prediction Errors")
    object EvaluateFalsifyVerify : EDDEPhase(11, "evaluate_falsify_verify", "\uD83D\uDCCA", "Evaluate, Falsify & Externally Verify")
    object ReflectDiagnose : EDDEPhase(12, "reflect_diagnose", "\uD83E\uDDE0", "Metacognitive Reflect & Diagnose")
    object ConsolidateMemoryProvenance : EDDEPhase(13, "consolidate_memory_provenance", "\uD83D\uDCBE", "Consolidate Memories, Skills & Provenance")
    object EvolvePolicyCurriculumArchitecture : EDDEPhase(14, "evolve_policy_curriculum_architecture", "\uD83E\uDDEC", "Evolve Policies, Curriculum & Architecture")

    companion object {
        val ALL = listOf(
            ActivePerceive, ExtractEssenceState, MapDecomposeChallenge,
            ArbitrateGoalsDirection, UpdateCausalModel, SimulateForecastUncertainty,
            GeneratePlansExperimentsRoutes, DecideRiskCostValues, PlanExecuteCheckpoints,
            ObserveOutcomesPredictionErrors, EvaluateFalsifyVerify, ReflectDiagnose,
            ConsolidateMemoryProvenance, EvolvePolicyCurriculumArchitecture
        )
        fun fromNumber(n: Int): EDDEPhase = ALL.first { it.number == n }
        fun fromName(name: String): EDDEPhase = ALL.first { it.name == name }
    }
}
