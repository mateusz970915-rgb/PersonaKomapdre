package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.edde.*
import com.example.edde.EDDEPipelineOrchestrator
import com.example.edde.EDDERuntime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * ViewModel dla EDDE+ 14-fazowego pipeline'u.
 * Wydzielony z ColonyViewModel (F-002 refaktoryzacja God Object).
 * Zarzadza cyklami EDDE+, event sourcing, checkpointami i weryfikacja.
 */
class EddeViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val dao = db.eddeDao()
    private val runtime = EDDERuntime(dao)
    private val orchestrator = EDDEPipelineOrchestrator(runtime, dao)

    // --- State Flows ---
    val pipelineRuns: StateFlow<List<EddePipelineRun>> = dao.getRecentPipelineRuns()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentRunId = MutableStateFlow<String?>(null)
    val currentRunId: StateFlow<String?> = _currentRunId

    private val _currentPhase = MutableStateFlow(0)
    val currentPhase: StateFlow<Int> = _currentPhase

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning

    private val _lastResult = MutableStateFlow<String?>(null)
    val lastResult: StateFlow<String?> = _lastResult

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // --- Public API ---

    fun runPipeline(objective: String, agentId: String = "EDDE-Agent") {
        viewModelScope.launch(Dispatchers.IO) {
            _isRunning.value = true
            _error.value = null
            _lastResult.value = null
            _currentPhase.value = 0

            try {
                val result = orchestrator.runPipeline(
                    context = getApplication(),
                    agentId = agentId,
                    objective = objective
                )

                if (result.isSuccess) {
                    _lastResult.value = result.getOrNull()
                } else {
                    _error.value = result.exceptionOrNull()?.message ?: "Unknown error"
                }
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isRunning.value = false
                _currentPhase.value = 14
            }
        }
    }

    fun getPhaseResults(runId: String): Flow<List<EddePhaseResult>> = flow {
        emit(dao.getPhaseResultsForRun(runId))
    }.flowOn(Dispatchers.IO)

    fun getEvents(runId: String): Flow<List<EddeEvent>> = flow {
        emit(dao.getEventsForRun(runId))
    }.flowOn(Dispatchers.IO)

    fun getEvidence(runId: String): Flow<List<EddeEvidence>> = flow {
        emit(dao.getEvidenceForRun(runId))
    }.flowOn(Dispatchers.IO)

    fun getPredictions(runId: String): Flow<List<EddePrediction>> = flow {
        emit(dao.getPredictionsForRun(runId))
    }.flowOn(Dispatchers.IO)

    fun getCheckpoints(runId: String): Flow<List<EddeCheckpoint>> = flow {
        emit(dao.getCheckpointsForRun(runId))
    }.flowOn(Dispatchers.IO)

    fun deleteOldRuns(olderThanDays: Int = 30) {
        viewModelScope.launch(Dispatchers.IO) {
            val cutoff = System.currentTimeMillis() - (olderThanDays * 24 * 60 * 60 * 1000L)
            dao.deleteOldRuns(cutoff)
        }
    }

    fun getRunById(runId: String): Flow<EddePipelineRun?> = flow {
        emit(dao.getPipelineRun(runId))
    }.flowOn(Dispatchers.IO)

    fun replayState(runId: String): Flow<Map<String, Any>> = flow {
        emit(runtime.replayDynamicState(runId))
    }.flowOn(Dispatchers.IO)
}
