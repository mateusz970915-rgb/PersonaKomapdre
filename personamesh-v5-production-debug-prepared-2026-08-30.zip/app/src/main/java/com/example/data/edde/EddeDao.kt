package com.example.data.edde

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface EddeDao {

    // --- Pipeline Runs ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPipelineRun(run: EddePipelineRun)

    @Query("SELECT * FROM edde_pipeline_runs WHERE runId = :runId")
    suspend fun getPipelineRun(runId: String): EddePipelineRun?

    @Query("SELECT * FROM edde_pipeline_runs WHERE agentId = :agentId ORDER BY createdAt DESC")
    fun getPipelineRunsForAgent(agentId: String): Flow<List<EddePipelineRun>>

    @Query("SELECT * FROM edde_pipeline_runs ORDER BY createdAt DESC LIMIT 50")
    fun getRecentPipelineRuns(): Flow<List<EddePipelineRun>>

    @Query("UPDATE edde_pipeline_runs SET status = :status, currentPhase = :currentPhase, completedAt = :completedAt WHERE runId = :runId")
    suspend fun updatePipelineRunStatus(runId: String, status: String, currentPhase: Int, completedAt: Long?)

    @Query("UPDATE edde_pipeline_runs SET verificationJson = :verificationJson WHERE runId = :runId")
    suspend fun updateVerification(runId: String, verificationJson: String)

    @Query("UPDATE edde_pipeline_runs SET evolutionJson = :evolutionJson WHERE runId = :runId")
    suspend fun updateEvolution(runId: String, evolutionJson: String)

    // --- Phase Results ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhaseResult(phase: EddePhaseResult)

    @Query("SELECT * FROM edde_phase_results WHERE runId = :runId ORDER BY phaseNumber ASC")
    suspend fun getPhaseResultsForRun(runId: String): List<EddePhaseResult>

    @Query("SELECT * FROM edde_phase_results WHERE runId = :runId AND phaseNumber = :phaseNumber")
    suspend fun getPhaseResult(runId: String, phaseNumber: Int): EddePhaseResult?

    @Query("UPDATE edde_phase_results SET status = :status, outputSnapshot = :output, executionTimeMs = :elapsed, tokensUsed = :tokens, errorMessage = :error WHERE phaseId = :phaseId")
    suspend fun updatePhaseCompletion(phaseId: String, status: String, output: String, elapsed: Long, tokens: Int, error: String?)

    // --- Events ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: EddeEvent)

    @Query("SELECT * FROM edde_events WHERE runId = :runId ORDER BY sequence ASC")
    suspend fun getEventsForRun(runId: String): List<EddeEvent>

    @Query("SELECT MAX(sequence) FROM edde_events WHERE runId = :runId")
    suspend fun getMaxSequence(runId: String): Int?

    // --- Evidence ---
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertEvidence(evidence: EddeEvidence)

    @Query("SELECT * FROM edde_evidence WHERE evidenceId = :evidenceId")
    suspend fun getEvidenceById(evidenceId: String): EddeEvidence?

    @Query("SELECT * FROM edde_evidence WHERE runId = :runId")
    suspend fun getEvidenceForRun(runId: String): List<EddeEvidence>

    // --- Predictions ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrediction(prediction: EddePrediction)

    @Query("UPDATE edde_predictions SET observed = :observed, result = :result WHERE predictionId = :predictionId")
    suspend fun updateObservation(predictionId: String, observed: String, result: String)

    @Query("SELECT * FROM edde_predictions WHERE runId = :runId")
    suspend fun getPredictionsForRun(runId: String): List<EddePrediction>

    // --- Checkpoints ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCheckpoint(checkpoint: EddeCheckpoint)

    @Query("UPDATE edde_checkpoints SET authorizationStatus = :status WHERE checkpointId = :checkpointId")
    suspend fun updateCheckpointStatus(checkpointId: String, status: String)

    @Query("SELECT * FROM edde_checkpoints WHERE runId = :runId")
    suspend fun getCheckpointsForRun(runId: String): List<EddeCheckpoint>

    // --- Cleanup ---
    @Query("DELETE FROM edde_pipeline_runs WHERE createdAt < :cutoff")
    suspend fun deleteOldRuns(cutoff: Long): Int

    @Transaction
    suspend fun deleteRunCascade(runId: String) {
        // Manual cascade — Room executes this in a transaction
    }
}
