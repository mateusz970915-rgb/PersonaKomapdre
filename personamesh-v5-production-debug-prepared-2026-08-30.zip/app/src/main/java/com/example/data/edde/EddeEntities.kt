package com.example.data.edde

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * 1. Pipeline Run — glowny rekord cyklu EDDE+ 14-fazowego.
 * Przechowuje stan calego cyklu, budzet, model przyczynowy, decyzje,
 * weryfikacje, refleksje, provenance, persistence i ewolucje.
 * Pola zagniezdzone sa serializowane do JSON (Room type converters).
 */
@Entity(
    tableName = "edde_pipeline_runs",
    indices = [
        Index(value = ["agentId"]),
        Index(value = ["status"]),
        Index(value = ["createdAt"])
    ]
)
@Serializable
data class EddePipelineRun(
    @PrimaryKey val runId: String,
    val agentId: String,
    val objective: String,
    val authorizationBoundary: String,
    val domainOwner: String = "provisional-read-only-owner",
    val closureOwner: String = "provisional-read-only-owner",
    val successCriteriaJson: String = "[]",
    val status: String = "active",
    val currentPhase: Int = 0,
    val cycleBudgetJson: String = """{"requestedMax":1,"remaining":0}""",
    val causalModelJson: String = "{}",
    val predictionsJson: String = "[]",
    val routesConsideredJson: String = "[]",
    val decisionJson: String = "{}",
    val checkpointsJson: String = "[]",
    val actionsJson: String = "[]",
    val artifactsJson: String = "[]",
    val observationsJson: String = "[]",
    val predictionErrorsJson: String = "[]",
    val verificationJson: String = """{"verdict":"not_run","criteria":[],"falsificationAttempts":[],"externalEvidence":[],"gaps":[]}""",
    val reflectionJson: String = "{}",
    val provenanceJson: String = "{}",
    val persistenceJson: String = """{"owner":"SANRuntime","location":"in-memory","updateStatus":"payload_provided"}""",
    val evolutionJson: String = "{}",
    val nextCycleJson: String = """{"decision":"pending","reason":"","reentryPhase":"","materialChange":"","expectedNewEvidence":""}""",
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)

/**
 * 2. Phase Result — wynik kazdej z 14 faz.
 * Jeden wiersz na faze, powiazany z runId.
 * Unikalny indeks (runId, phaseNumber) zapobiega duplikatom.
 */
@Entity(
    tableName = "edde_phase_results",
    indices = [
        Index(value = ["runId", "phaseNumber"], unique = true),
        Index(value = ["runId"]),
        Index(value = ["status"])
    ]
)
@Serializable
data class EddePhaseResult(
    @PrimaryKey val phaseId: String,
    val runId: String,
    val phaseNumber: Int,
    val phaseName: String,
    val inputSnapshot: String = "",
    val outputSnapshot: String = "",
    val status: String = "pending",
    val executionTimeMs: Long = 0,
    val tokensUsed: Int = 0,
    val errorMessage: String? = null,
    val evidenceRefsJson: String = "[]",
    val assumptionsJson: String = "[]",
    val unknownsJson: String = "[]",
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 3. Event — append-only event log z hash chain (SHA-256).
 * Kazde zdarzenie ma sequence, previousEventHash i eventHash.
 * To zrodlo prawdy dla calego cyklu — record.json to tylko projekcja.
 */
@Entity(
    tableName = "edde_events",
    indices = [
        Index(value = ["runId", "sequence"], unique = true),
        Index(value = ["runId"]),
        Index(value = ["eventType"]),
        Index(value = ["eventHash"])
    ]
)
@Serializable
data class EddeEvent(
    @PrimaryKey val eventId: String,
    val runId: String,
    val eventType: String,
    val payloadJson: String = "{}",
    val sequence: Int,
    val previousEventHash: String = "",
    val eventHash: String,
    val actor: String = "SANRuntime",
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 4. Evidence — content-addressable store (hash = primary key).
 * Dedupikacja: identyczna tresc = ten sam evidenceId.
 * Rozroznia dowody wewnetrzne (phase_output) i zewnetrzne.
 */
@Entity(
    tableName = "edde_evidence",
    indices = [
        Index(value = ["runId"]),
        Index(value = ["phaseName"]),
        Index(value = ["kind"])
    ]
)
@Serializable
data class EddeEvidence(
    @PrimaryKey val evidenceId: String,
    val runId: String,
    val kind: String,
    val content: String,
    val phaseName: String? = null,
    val isExternal: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 5. Prediction — predykcja + obserwacja + blad predykcji.
 * Przechowuje expected outcome, failure signal, observed result.
 * Rozroznia: matched, mismatch, not_observed.
 */
@Entity(
    tableName = "edde_predictions",
    indices = [
        Index(value = ["runId"]),
        Index(value = ["predictionId"], unique = true)
    ]
)
@Serializable
data class EddePrediction(
    @PrimaryKey val id: Int = 0,
    val runId: String,
    val predictionId: String,
    val expected: String,
    val failureSignal: String,
    val observed: String? = null,
    val result: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 6. Checkpoint — punkt kontrolny przed akcjami destrukcyjnymi/drogimi.
 * Stan: pending -> granted / denied.
 * Rollback plan przechowywany jako JSON string.
 */
@Entity(
    tableName = "edde_checkpoints",
    indices = [
        Index(value = ["runId"]),
        Index(value = ["checkpointId"], unique = true)
    ]
)
@Serializable
data class EddeCheckpoint(
    @PrimaryKey val id: Int = 0,
    val runId: String,
    val checkpointId: String,
    val action: String,
    val rollback: String,
    val authorizationStatus: String = "pending",
    val timestamp: Long = System.currentTimeMillis()
)
