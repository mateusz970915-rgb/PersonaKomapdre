package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.example.viewmodel.ColonyViewModel
import com.example.data.Agent
import kotlinx.coroutines.flow.emptyFlow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ColonyViewModel,
    onBack: () -> Unit
) {
    val agents by viewModel.agents.collectAsState(initial = emptyList())
    var selectedAgent by remember { mutableStateOf<Agent?>(null) }
    var messageText by remember { mutableStateOf("") }
    
    // Default select first agent if none is selected
    LaunchedEffect(agents) {
        if (selectedAgent == null && agents.isNotEmpty()) {
            selectedAgent = agents.first()
        }
    }
    
    // We collect the flow of messages for the selected agent
    val messagesFlow = remember(selectedAgent) {
        if (selectedAgent != null) {
            viewModel.getUserAgentMessages(selectedAgent!!.name)
        } else {
            emptyFlow()
        }
    }
    val messages by messagesFlow.collectAsState(initial = emptyList())

    var expanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Box(modifier = Modifier.fillMaxWidth().wrapContentSize(Alignment.TopStart)) {
                        TextButton(onClick = { expanded = true }) {
                            Text(text = selectedAgent?.name ?: "Select Agent", style = MaterialTheme.typography.titleLarge)
                        }
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            agents.forEach { agent ->
                                DropdownMenuItem(
                                    text = { Text(agent.name) },
                                    onClick = {
                                        selectedAgent = agent
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                reverseLayout = true
            ) {
                items(messages.reversed()) { message ->
                    val isUser = message.role == "user"
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
                            modifier = Modifier.widthIn(max = 280.dp)
                        ) {
                            Text(
                                text = message.content,
                                modifier = Modifier.padding(12.dp),
                                color = if (isUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            }
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = messageText,
                    onValueChange = { messageText = it },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input"),
                    placeholder = { Text("Message ${selectedAgent?.name ?: "agent"}...") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (messageText.isNotBlank() && selectedAgent != null) {
                                viewModel.insertUserAgentMessage(selectedAgent!!.name, "user", messageText)
                                messageText = ""
                            }
                        }
                    )
                )
                
                IconButton(
                    onClick = {
                        if (messageText.isNotBlank() && selectedAgent != null) {
                            viewModel.insertUserAgentMessage(selectedAgent!!.name, "user", messageText)
                            messageText = ""
                        }
                    },
                    modifier = Modifier.testTag("chat_send_button"),
                    enabled = messageText.isNotBlank() && selectedAgent != null
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send Message", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}
