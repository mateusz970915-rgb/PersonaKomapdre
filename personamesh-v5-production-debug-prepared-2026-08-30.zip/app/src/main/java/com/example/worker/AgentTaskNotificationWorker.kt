package com.example.worker

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.data.AppDatabase
import com.example.network.AILlmClient
import com.example.utils.NotificationHelper
import kotlinx.coroutines.flow.first

class AgentTaskNotificationWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val taskId = inputData.getInt("TASK_ID", -1)
        if (taskId == -1) {
            Log.w("AgentTaskNotification", "No TASK_ID provided")
            return Result.success()
        }

        val database = AppDatabase.getDatabase(applicationContext)
        val dao = database.colonyDao()
        
        try {
            val subTasks = dao.getAllSubTasks().first()
            val task = subTasks.find { it.id == taskId } ?: return Result.success()
            
            val agents = dao.getAllAgents().first()
            val agent = agents.find { it.name.equals(task.assignedAgent, ignoreCase = true) } ?: return Result.success()

            val prompt = """
                You are ${agent.name}, an AI with role: ${agent.role}.
                You have just completed the following background task:
                "${task.description}"
                Write a very concise (1 short sentence, max 15 words) notification message to the user summarizing what you accomplished in your persona's voice. Do not use quotes or introductory phrases.
            """.trimIndent()
            
            val summary = AILlmClient.generateContent(applicationContext, prompt).trim()
            
            NotificationHelper.sendNotification(
                applicationContext,
                taskId,
                "${agent.name} (Task Completed)",
                summary
            )

            return Result.success()
        } catch (e: Exception) {
            Log.e("AgentTaskNotificationWorker", "Error sending notification", e)
            return Result.failure()
        }
    }
}
