package com.example.worker

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.data.AppDatabase
import com.example.data.ColonyMemory
import com.example.engine.ExecutionEngine
import com.example.security.PolicyEnforcementPoint
import kotlinx.coroutines.flow.first

class ColonyBackgroundProcessingWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        if (!PolicyEnforcementPoint.enforceBackgroundExecution(applicationContext)) {
            Log.i("ColonyBackgroundWorker", "Background execution blocked by policy.")
            return Result.success()
        }

        val database = AppDatabase.getDatabase(applicationContext)
        val dao = database.colonyDao()
        val engine = ExecutionEngine(applicationContext)

        try {
            val agents = dao.getAllAgents().first()
            val subTasks = dao.getAllSubTasks().first()

            val pendingTasks = subTasks.filter { it.status == "Pending" || it.status == "In Progress" }

            if (pendingTasks.isEmpty()) {
                return Result.success()
            }

            for (task in pendingTasks) {
                // Find assigned agent
                val agent = agents.find { it.name.equals(task.assignedAgent, ignoreCase = true) }
                if (agent == null) {
                    val updated = task.copy(status = "Failed", completedAt = System.currentTimeMillis())
                    dao.insertSubTask(updated)
                    dao.insertMemory(ColonyMemory(content = "Task ${task.id} failed: Agent ${task.assignedAgent} not found."))
                    continue
                }

                // Agents can only work if they are Active
                if (agent.status != "Active") {
                    Log.i("ColonyBackgroundWorker", "Task ${task.id} deferred: Agent ${agent.name} is ${agent.status}.")
                    continue
                }

                // Execute via engine
                val result = engine.executeTask(task, agent)
                
                // Update task status
                val isTerminal = result.status == "EXECUTED" || result.status == "SIMULATED" || result.status == "FAILED"
                val updatedTask = task.copy(
                    status = result.status, 
                    completedAt = if (isTerminal) System.currentTimeMillis() else 0L
                )
                dao.insertSubTask(updatedTask)

                // Log result to memory
                dao.insertMemory(ColonyMemory(content = "Background Task [${task.id}] by ${agent.name}: ${result.logMessage}"))
                
                if (isTerminal && result.status != "FAILED") {
                    val inputData = androidx.work.Data.Builder()
                        .putInt("TASK_ID", task.id)
                        .build()
                    val notificationRequest = androidx.work.OneTimeWorkRequestBuilder<AgentTaskNotificationWorker>()
                        .setInputData(inputData)
                        .build()
                    androidx.work.WorkManager.getInstance(applicationContext).enqueue(notificationRequest)
                }
            }

            return Result.success()
        } catch (e: Exception) {
            Log.e("ColonyBackgroundWorker", "Error processing tasks", e)
            return Result.retry()
        }
    }
}
