import re

with open('app/src/main/java/com/example/ui/DashboardScreen.kt', 'r') as f:
    content = f.read()

target = """    onNavigateToInteractions: () -> Unit = {},
    onNavigateToPersonaMesh: () -> Unit = {},\n) {"""

replacement = """    onNavigateToInteractions: () -> Unit = {},
    onNavigateToPersonaMesh: () -> Unit = {},
    onNavigateToColonyDashboard: () -> Unit = {},\n) {"""

if target in content:
    content = content.replace(target, replacement)
    
    # Now find where to add the button
    target_btn = """                                    DashboardTile("Activity Heatmap", Icons.Default.Timeline, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer) {
                                        onNavigateToActivityHeatmap()
                                    }
                                }"""
    replacement_btn = """                                    DashboardTile("Activity Heatmap", Icons.Default.Timeline, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer) {
                                        onNavigateToActivityHeatmap()
                                    }
                                }
                                Spacer(modifier = Modifier.height(16.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    DashboardTile("Colony Dashboard", Icons.Default.Dashboard, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer) {
                                        onNavigateToColonyDashboard()
                                    }
                                }"""
    if target_btn in content:
        content = content.replace(target_btn, replacement_btn)
    
    with open('app/src/main/java/com/example/ui/DashboardScreen.kt', 'w') as f:
        f.write(content)
    print("DashboardScreen updated")
else:
    print("Target not found")
