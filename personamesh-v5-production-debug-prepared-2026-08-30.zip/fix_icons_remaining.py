import os

replacements = [
    ("ViewList", "ViewList"),
    ("Chat", "Chat"),
    ("CompareArrows", "CompareArrows"),
    ("FactCheck", "FactCheck"),
    ("Message", "Message")
]

target_dir = "app/src/main/java/com/example/ui"

for root, _, files in os.walk(target_dir):
    for file in files:
        if file.endswith(".kt"):
            filepath = os.path.join(root, file)
            with open(filepath, "r") as f:
                content = f.read()
            
            new_content = content
            for icon_name, _ in replacements:
                # Replace Icons.Default.IconName
                new_content = new_content.replace(f"Icons.Default.{icon_name}", f"Icons.AutoMirrored.Filled.{icon_name}")
                # Replace Icons.Filled.IconName
                new_content = new_content.replace(f"Icons.Filled.{icon_name}", f"Icons.AutoMirrored.Filled.{icon_name}")
                # Replace explicit imports
                new_content = new_content.replace(
                    f"androidx.compose.material.icons.filled.{icon_name}",
                    f"androidx.compose.material.icons.automirrored.filled.{icon_name}"
                )
                
            if new_content != content:
                with open(filepath, "w") as f:
                    f.write(new_content)
                print(f"Updated {filepath}")

