import re

with open('app/src/main/java/com/example/viewmodel/ColonyViewModel.kt', 'r') as f:
    content = f.read()

new_method = """
    fun triggerAgentHelpRequest(requester: Agent, focusArea: String) {
        if (focusArea == "Idle / Awaiting Task") {
            sendInterAgentMessage(requester.name, requester.type, "I'm currently idle. Does anyone have a task I can help with?", null, "Task Assignment")
            return
        }

        viewModelScope.launch {
            if (isApiKeyConfigured) {
                // 1. Requester generates a message asking for help
                val requestPrompt = \"\"\"
                    You are ${requester.name}, an AI Agent with role ${requester.role}.
                    Your current focus area is: "$focusArea".
                    Write a 1-sentence message to the colony asking for information, advice, or collaboration on this specific focus area.
                    Do not include your name at the beginning, just the message.
                \"\"\".trimIndent()
                
                val requestMessage = try {
                    com.example.network.AILlmClient.generateContent(getApplication(), requestPrompt).trim()
                } catch (e: Exception) {
                    "Can anyone assist me or share insights regarding my current focus area: $focusArea?"
                }
                
                sendInterAgentMessage(requester.name, requester.type, requestMessage, null, "Collaboration")
                
                // 2. Select 1-2 other active agents to respond
                val availableResponders = agents.value.filter { 
                    it.id != requester.id && (it.status == "Active" || it.status == "Busy" || it.status == "Working") 
                }.shuffled().take(2)
                
                for (responder in availableResponders) {
                    val replyPrompt = \"\"\"
                        You are ${responder.name}, role: ${responder.role}.
                        Your colleague ${requester.name} just broadcasted this message:
                        "$requestMessage"
                        
                        Write a 1-sentence response offering help, sharing relevant knowledge from your domain, or suggesting a joint approach.
                        Do not include your name at the beginning, just the message.
                    \"\"\".trimIndent()
                    
                    val replyMessage = try {
                        com.example.network.AILlmClient.generateContent(getApplication(), replyPrompt).trim()
                    } catch (e: Exception) {
                        "I can certainly help you with that from my perspective."
                    }
                    sendInterAgentMessage(responder.name, responder.type, replyMessage, requester.name, "Collaboration")
                }
            } else {
                sendInterAgentMessage(requester.name, requester.type, "I need help with my focus area: $focusArea. (API Key not configured)", null, "Collaboration")
            }
        }
    }
"""

target = "fun initiateAgentDiscussion(topic: String) {"

if target in content:
    content = content.replace(target, new_method + "\n    " + target)
    with open('app/src/main/java/com/example/viewmodel/ColonyViewModel.kt', 'w') as f:
        f.write(content)
    print("Added triggerAgentHelpRequest")
else:
    print("Target not found")
