#!/bin/bash
declare -a icons=(
  "ArrowBack"
  "ArrowForward"
  "Label"
  "Chat"
  "Message"
  "ManageSearch"
  "FactCheck"
  "KeyboardArrowRight"
  "Article"
  "TrendingUp"
  "TrendingDown"
  "TrendingFlat"
  "ShowChart"
  "MultilineChart"
  "List"
  "Assignment"
  "Send"
)

for icon in "${icons[@]}"; do
  find app/src -type f -name "*.kt" -exec sed -i "s/Icons.AutoMirrored.Filled.${icon}/Icons.Filled.${icon}/g" {} +
  find app/src -type f -name "*.kt" -exec sed -i "s/androidx.compose.material.icons.automirrored.filled.${icon}/androidx.compose.material.icons.filled.${icon}/g" {} +
done
