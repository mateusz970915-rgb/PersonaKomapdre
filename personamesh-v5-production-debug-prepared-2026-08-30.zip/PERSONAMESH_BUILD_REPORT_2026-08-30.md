# PersonaMesh — raport próby kompilacji APK

Data: 2026-08-30  
Wariant docelowy: `:app:assembleProductionDebug`  
Werdykt: **BLOCKED — APK nie został jeszcze wygenerowany**

## Wynik

Projekt został rozpakowany i przygotowany do kompilacji. Próba:

```text
./gradlew :app:assembleProductionDebug --stacktrace
```

zatrzymuje się przed konfiguracją projektu, ponieważ wrapper próbuje pobrać
`gradle-9.3.1-bin.zip`, a środowisko zwraca:

```text
java.net.SocketException: Network is unreachable
```

W środowisku nie ma też lokalnie dostępnego Gradle, Android SDK ani narzędzi
`sdkmanager`, `adb`, `aapt`, `apkanalyzer` i `zipalign`. Nie powstał plik APK:
`app/build/outputs/apk/production/debug/` jest pusty/nieobecny.

Zdalna próba na GitHub Actions potwierdziła, że ścieżka CI działa dalej niż
lokalny workspace: checkout, JDK 17, rozpakowanie archiwum i walidacja assetów
przeszły poprawnie. Run #8 zatrzymał się dopiero na kompilacji Kotlin:

```text
:app:compileProductionDebugKotlin FAILED
BUILD FAILED in 2m 54s
```

Pierwszy zestaw błędów dotyczył niespójności `ExportDatabaseWorker` z aktualnymi
DAO/encjami oraz brakującej metody `ColonyViewModel.addSelfHealingProposal`.
Te referencje zostały poprawione w bieżącej kopii roboczej. Druga próba CI
(runy #9 i #10) potwierdziła te poprawki i doszła dalej, ale zatrzymała się na
brakującym parametrze `eddeViewModel` w `MainActivity.kt`:

```text
MainActivity.kt:466:25 No value passed for parameter 'eddeViewModel'
```

Parametr i instancja `EddeViewModel` zostały teraz dodane do bieżącej kopii;
następny run CI ma potwierdzić przejście kompilacji.

## Co zostało naprawione w kopii roboczej

- przywrócono poprawny `gradle/wrapper/gradle-wrapper.jar` zgodny z Gradle 9.3.1;
- ustawiono wykonywanie `gradlew` (`mode 755`);
- przywrócono poprawne dane JPEG dla `img_app_icon.jpg` i `img_mesh_hero.jpg`;
- uzupełniono migracje Room `31→32` i `32→33`;
- uzupełniono brakujące indeksy w migracji EDDE `33→34`;
- usunięto z ręcznej migracji EDDE niezgodne domyślne wartości SQL — domyślne
  wartości Kotlin nie są domyślnymi wartościami kolumn Room;
- poprawiono README i workflow CI tak, aby używały jednoznacznie wariantu
  `productionDebug` oraz publikowały jego APK.
- podłączono `EddeViewModel` w `MainActivity` do `EddeConsoleScreen` zgodnie z
  aktualną sygnaturą composable.

## Kontrole wykonane lokalnie

| Kontrola | Status |
|---|---|
| test integralności wrapper JAR (`unzip -t`) | PASS |
| składnia skryptu `gradlew` | PASS |
| JPEG/WebP w `app/src/main/res` | PASS — 2 JPEG, 10 WebP |
| parsowanie XML zasobów | PASS — 12 plików |
| parsowanie workflow YAML i obecność tasków CI | PASS |
| statyczna kontrola migracji Room do wersji 34 | PASS |
| `./gradlew :app:assembleProductionDebug` | BLOCKED — brak dystrybucji/network |
| zdalny bootstrap Gradle/Android na GitHub Actions | PASS — run #8 |
| zdalna kompilacja Kotlin | FAIL — niespójne referencje w pierwszej próbie |
| kompilacja Kotlin/Java po poprawkach DAO/ViewModel | PASS — runy #9/#10 przeszły dalej; wykryto następny brakujący parametr UI |
| kompilacja Kotlin/Java po podłączeniu `EddeViewModel` | NOT RUN — oczekuje na kolejny run |
| lint, testy jednostkowe | NOT RUN — przerwane po błędzie kompilacji |
| inspekcja manifestu/signature/APK | NOT RUN — APK nie istnieje |
| instalacja przez ADB | NOT RUN — brak APK i ADB |

## Sumy SHA-256 kopii roboczej

```text
gradle/wrapper/gradle-wrapper.jar
b3a875ddc1f044746e1b1a55f645584505f4a10438c1afea9f15e92a7c42ec13

app/src/main/res/drawable/img_app_icon.jpg
b1cceb6fa8785bf4d416b171435bfc6cfd5a97694fe620ced4a29c6c5f5a8544

app/src/main/res/drawable/img_mesh_hero.jpg
59ed38493c71bfdeaf2d735157f88da3e9384861786bd6df9793bc637fc48184
```

## Następny krok na maszynie buildowej

W katalogu projektu uruchomić:

```bash
./gradlew :app:lintProductionDebug \
  :app:testProductionDebugUnitTest \
  :app:assembleProductionDebug
```

Wynik powinien trafić do:

```text
app/build/outputs/apk/production/debug/
```

`productionDebug` jest wariantem instalacyjnym podpisanym debugowym kluczem
Androida. Wydanie release wymaga osobnego keystore i nie było wykonywane ani
pozorowane bez dostarczonych sekretów.
