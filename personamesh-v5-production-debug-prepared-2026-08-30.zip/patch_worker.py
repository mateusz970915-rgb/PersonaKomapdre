import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """                            val memorySnapshotRequest = PeriodicWorkRequestBuilder<com.example.workers.MemorySnapshotWorker>(24, TimeUnit.HOURS).build()
                            WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork("MemorySnapshotWork", ExistingPeriodicWorkPolicy.KEEP, memorySnapshotRequest)
                        } catch (e: Exception) { e.printStackTrace() }"""

replacement = """                            val memorySnapshotRequest = PeriodicWorkRequestBuilder<com.example.workers.MemorySnapshotWorker>(24, TimeUnit.HOURS).build()
                            WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork("MemorySnapshotWork", ExistingPeriodicWorkPolicy.KEEP, memorySnapshotRequest)
                        } catch (e: Exception) { e.printStackTrace() }
                        
                        try {
                            val backgroundProcessingRequest = PeriodicWorkRequestBuilder<com.example.worker.ColonyBackgroundProcessingWorker>(15, TimeUnit.MINUTES).build()
                            WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
                                "ColonyBackgroundProcessingWork",
                                ExistingPeriodicWorkPolicy.KEEP,
                                backgroundProcessingRequest
                            )
                        } catch (e: Exception) { e.printStackTrace() }"""

if target in content:
    content = content.replace(target, replacement)
    with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
        f.write(content)
    print("MainActivity updated")
else:
    print("Target not found in MainActivity.kt")
