import re

with open('app/src/main/java/com/example/utils/ApiGateway.kt', 'r') as f:
    content = f.read()

new_webhook = """                    createContext("/webhook") { exchange ->
                        if ("POST" == exchange.requestMethod) {
                            val authHeader = exchange.requestHeaders.getFirst("Authorization")
                            if (authHeader == null || !authHeader.startsWith("Bearer ") || authHeader.substring(7) != "TEST_WEBHOOK_SECRET") {
                                val response = "Unauthorized"
                                exchange.sendResponseHeaders(401, response.length.toLong())
                                exchange.responseBody.use { os ->
                                    os.write(response.toByteArray())
                                }
                                return@createContext
                            }
                            
                            val inputStream = exchange.requestBody
                            val requestBody = inputStream.bufferedReader().use { it.readText() }
                            
                            val content = if (requestBody.isNotBlank()) requestBody else "Webhook received (Empty Body)"
                            onMessageReceived(content)
                            
                            val response = "Acknowledged"
                            exchange.sendResponseHeaders(200, response.length.toLong())
                            exchange.responseBody.use { os ->
                                os.write(response.toByteArray())
                            }
                        } else {
                            val response = "Method Not Allowed"
                            exchange.sendResponseHeaders(405, response.length.toLong())
                            exchange.responseBody.use { os ->
                                os.write(response.toByteArray())
                            }
                        }
                    }"""

old_webhook_pattern = r'                    createContext\("/webhook"\) \{ exchange ->.*?\}\n                        \} else \{\n.*?\}\n                        \}\n                    \}'

match = re.search(old_webhook_pattern, content, re.DOTALL)
if match:
    content = content[:match.start()] + new_webhook + content[match.end():]
    with open('app/src/main/java/com/example/utils/ApiGateway.kt', 'w') as f:
        f.write(content)
    print("ApiGateway patched")
else:
    print("Could not find webhook pattern")
