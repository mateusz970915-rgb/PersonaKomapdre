import re
with open('app/src/main/java/com/example/viewmodel/BaseAgentViewModel.kt', 'r') as f:
    content = f.read()

fixed = content.replace("""    fun triggerInteractionAnomalyCheck() {
        viewModelScope.launch {
            if (com.example.security.PolicyEnforcementPoint.enforceBackgroundExecution(getApplication())) {
                try {
                        val workManager = androidx.work.WorkManager.getInstance(getApplication())
                        val request = androidx.work.OneTimeWorkRequestBuilder<com.example.worker.InteractionAnomalyWorker>().build()
                        workManager.enqueue(request)
                    }
        }
    } catch (e: Exception) {
            e.printStackTrace()
        }
    }""", """    fun triggerInteractionAnomalyCheck() {
        viewModelScope.launch {
            if (com.example.security.PolicyEnforcementPoint.enforceBackgroundExecution(getApplication())) {
                try {
                    val workManager = androidx.work.WorkManager.getInstance(getApplication())
                    val request = androidx.work.OneTimeWorkRequestBuilder<com.example.worker.InteractionAnomalyWorker>().build()
                    workManager.enqueue(request)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }""")

fixed = fixed.replace("""    fun triggerAgentDataSync() {
        viewModelScope.launch {
            if (com.example.security.PolicyEnforcementPoint.enforceBackgroundExecution(getApplication())) {
                try {
                        val workManager = androidx.work.WorkManager.getInstance(getApplication())
                        val request = androidx.work.OneTimeWorkRequestBuilder<com.example.worker.AgentDataSyncWorker>().build()
                        workManager.enqueue(request)
                    }
        }
    } catch (e: Exception) {
            e.printStackTrace()
        }
    }""", """    fun triggerAgentDataSync() {
        viewModelScope.launch {
            if (com.example.security.PolicyEnforcementPoint.enforceBackgroundExecution(getApplication())) {
                try {
                    val workManager = androidx.work.WorkManager.getInstance(getApplication())
                    val request = androidx.work.OneTimeWorkRequestBuilder<com.example.worker.AgentDataSyncWorker>().build()
                    workManager.enqueue(request)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }""")

with open('app/src/main/java/com/example/viewmodel/BaseAgentViewModel.kt', 'w') as f:
    f.write(fixed)
