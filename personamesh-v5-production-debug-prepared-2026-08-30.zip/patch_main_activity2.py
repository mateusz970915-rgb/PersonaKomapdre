import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """                    composable("persona_colony") {
                        com.example.ui.PersonaColonyScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }"""

replacement = """                    composable("persona_colony") {
                        com.example.ui.PersonaColonyScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() },
                            onNavigateToDashboard = { navController.navigate("colony_dashboard") }
                        )
                    }"""

if target in content:
    content = content.replace(target, replacement)
    with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
        f.write(content)
    print("MainActivity updated 2")
else:
    print("Target not found in MainActivity 2")
