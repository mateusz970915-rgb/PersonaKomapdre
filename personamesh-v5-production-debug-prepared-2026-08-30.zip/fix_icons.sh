#!/bin/bash
declare -a icons=(
  "ArrowBack"
  "ArrowForward"
  "Label"
  "Chat"
  "Message"
  "ManageSearch"
  "FactCheck"
  "KeyboardArrowRight"
  "Article"
  "TrendingUp"
  "TrendingDown"
  "TrendingFlat"
  "ShowChart"
  "MultilineChart"
  "List"
  "Assignment"
  "Send"
)

for icon in "${icons[@]}"; do
  find app/src -type f -name "*.kt" -exec sed -i "s/Icons.Filled.${icon}/Icons.AutoMirrored.Filled.${icon}/g" {} +
done

# Fix destructive migration
find app/src/main/java/com/example/data -type f -name "AppDatabase.kt" -exec sed -i "s/fallbackToDestructiveMigration()/fallbackToDestructiveMigration(dropAllTables = true)/g" {} +
