import re

with open('app/src/main/java/com/example/ui/PersonaColonyScreen.kt', 'r') as f:
    content = f.read()

target = """androidx.compose.material.icons.Icons.Default.Home"""
replacement = """Icons.Filled.Settings"""

if target in content:
    content = content.replace(target, replacement)
    with open('app/src/main/java/com/example/ui/PersonaColonyScreen.kt', 'w') as f:
        f.write(content)
    print("Fixed icon in PersonaColonyScreen to Settings")
else:
    print("Target not found")
