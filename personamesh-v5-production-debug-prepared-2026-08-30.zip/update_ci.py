import re

with open('.github/workflows/android.yml', 'r') as f:
    content = f.read()

# Add wrapper validation step
validation_step = """
    - name: Validate Gradle Wrapper
      uses: gradle/wrapper-validation-action@v2
"""

if "wrapper-validation-action" not in content:
    content = content.replace("    - name: Set up JDK 17", validation_step.strip('\n') + "\n    - name: Set up JDK 17")
    
    with open('.github/workflows/android.yml', 'w') as f:
        f.write(content)
