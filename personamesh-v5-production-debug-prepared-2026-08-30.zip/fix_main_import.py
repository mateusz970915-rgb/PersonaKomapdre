import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace("import android.os.Build", "import android.os.Build\nimport androidx.lifecycle.lifecycleScope\nimport kotlinx.coroutines.launch")
content = content.replace("androidx.lifecycle.lifecycleScope.launch {", "lifecycleScope.launch {")

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
