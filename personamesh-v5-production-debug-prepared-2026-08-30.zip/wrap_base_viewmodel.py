import re

with open('app/src/main/java/com/example/viewmodel/BaseAgentViewModel.kt', 'r') as f:
    content = f.read()

# fun triggerInteractionAnomalyCheck() {
# ...
# }
# fun triggerAgentDataSync() {
# ...
# }

def wrap_function(func_name, content):
    pattern = rf'(fun {func_name}\(\) {{\n)(.*?)(    }})'
    match = re.search(pattern, content, re.DOTALL)
    if match:
        inner = match.group(2)
        indented = inner.replace('\n', '\n            ')
        new_inner = f"        viewModelScope.launch {{\n            if (com.example.security.PolicyEnforcementPoint.enforceBackgroundExecution(getApplication())) {{\n        {indented}    }}\n        }}\n"
        return content[:match.start()] + match.group(1) + new_inner + match.group(3) + content[match.end():]
    return content

content = wrap_function('triggerInteractionAnomalyCheck', content)
content = wrap_function('triggerAgentDataSync', content)

with open('app/src/main/java/com/example/viewmodel/BaseAgentViewModel.kt', 'w') as f:
    f.write(content)
print("BaseAgentViewModel updated")
