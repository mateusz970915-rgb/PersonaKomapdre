import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

start_pattern = r'try \{ val dailySummaryRequest = PeriodicWorkRequestBuilder<DailySummaryWorker>\(1, TimeUnit\.DAYS\)\.build\(\)'
end_pattern = r'enableEdgeToEdge\(\)'

match_start = re.search(start_pattern, content)
match_end = re.search(end_pattern, content)

if match_start and match_end:
    start_idx = match_start.start()
    end_idx = match_end.start()
    
    inner_block = content[start_idx:end_idx]
    
    indented_inner = inner_block.replace('\n', '\n                ')
    new_inner_block = f"""androidx.lifecycle.lifecycleScope.launch {{
            if (com.example.security.PolicyEnforcementPoint.enforceBackgroundExecution(applicationContext)) {{
                {indented_inner}
            }}
        }}
        """
    
    content = content[:start_idx] + new_inner_block + content[end_idx:]
    
    with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
        f.write(content)
    print("MainActivity updated")
else:
    print("Could not find patterns")
